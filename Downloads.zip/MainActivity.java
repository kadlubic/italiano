package com.example.licznik;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int _counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void zwieksz(View view) {
        _counter++;
        updateCounter();
    }

    public void zmniejsz(View view) {
        _counter--;
        updateCounter();
    }
    public void wyzeruj(View view) {
        _counter=0;
        updateCounter();
    }

    public void ustaw(View view) {
        final EditText editText = new EditText(this);
        editText.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

        new AlertDialog.Builder(this)
                .setTitle("Ustaw licznik")
                .setView(editText)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        _counter = Integer.parseInt(editText.getText().toString());
                        updateCounter();
                    }
                })
                .setNegativeButton("Anuluj", null)
                .show();
    }

    private void updateCounter(){
        String s = String.valueOf(_counter);
        TextView textView = (TextView) findViewById(R.id.value);
        textView.setText(s);
    }

}